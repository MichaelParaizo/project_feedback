package com.meuapp.feedback.repository;

import com.meuapp.feedback.domain.Feedback;
import com.meuapp.feedback.domain.Restaurant;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface FeedbackRepository extends JpaRepository<Feedback, Long> {

    // Todos de um restaurante
    List<Feedback> findByRestaurant(Restaurant restaurant);

    // Negativos (nota <= 3)
    List<Feedback> findByRestaurantAndNotaLessThanEqual(Restaurant restaurant, int nota);

    // Positivos (nota >= 4)
    List<Feedback> findByRestaurantAndNotaGreaterThanEqual(Restaurant restaurant, int nota);

    // Cupom validado
    List<Feedback> findByRestaurantAndCupomValidadoTrue(Restaurant restaurant);

    // Cupom pendente
    List<Feedback> findByRestaurantAndCupomValidadoFalse(Restaurant restaurant);

    // Buscar por código do cupom
    Optional<Feedback> findByCupom(String cupom);
}
