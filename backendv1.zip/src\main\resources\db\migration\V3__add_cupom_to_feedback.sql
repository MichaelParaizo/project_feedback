ALTER TABLE feedback
ADD COLUMN IF NOT EXISTS cupom varchar(64);
