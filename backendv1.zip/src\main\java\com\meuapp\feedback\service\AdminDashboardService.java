package com.meuapp.feedback.service;

import com.meuapp.feedback.domain.Feedback;
import com.meuapp.feedback.domain.Restaurant;
import com.meuapp.feedback.dto.dashboard.*;
import com.meuapp.feedback.repository.FeedbackRepository;
import com.meuapp.feedback.repository.RestaurantRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AdminDashboardService {

    private final FeedbackRepository feedbackRepository;
    private final RestaurantRepository restaurantRepository;

    public DashboardResponseDTO gerarDashboard(Long restaurantId) {

        Restaurant restaurant = restaurantRepository.findById(restaurantId)
                .orElseThrow(() -> new RuntimeException("Restaurante não encontrado"));

        // Carrega TODOS os feedbacks do restaurante
        List<Feedback> feedbacks = feedbackRepository.findByRestaurant(restaurant);

        long totalFeedbacks = feedbacks.size();

        long positivos = feedbacks.stream()
                .filter(f -> f.getNota() >= 4)
                .count();

        long negativos = feedbacks.stream()
                .filter(f -> f.getNota() <= 3)
                .count();

        double positivosPercent = totalFeedbacks > 0
                ? (positivos * 100.0) / totalFeedbacks
                : 0.0;

        double negativosPercent = totalFeedbacks > 0
                ? (negativos * 100.0) / totalFeedbacks
                : 0.0;

        // Novos clientes hoje (feedbacks do dia)
        LocalDate hoje = LocalDate.now();
        long novosClientesHoje = feedbacks.stream()
                .filter(f -> f.getDataCriacao() != null &&
                        f.getDataCriacao().toLocalDate().isEqual(hoje))
                .count();

        // Cupons
        long cuponsSolicitados = feedbacks.stream()
                .filter(f -> f.getCupom() != null && !f.getCupom().isBlank())
                .count();

        long cuponsValidados = feedbacks.stream()
                .filter(f -> Boolean.TRUE.equals(f.getCupomValidado()))
                .count();

        // Principais reclamações (versão simples: agrupa mensagens negativas iguais)
        List<ReclamacaoItemDTO> reclamacoes = calcularPrincipaisReclamacoes(feedbacks);

        // Timeline últimos 7 dias
        List<TimelinePontoDTO> timelineFeedbacks = montarTimelineFeedbacks(hoje, feedbacks);
        List<TimelinePontoDTO> timelineCupons = montarTimelineCupons(hoje, feedbacks);

        // Monta DTOs

        MetricasGeraisDTO metricasGeraisDTO = MetricasGeraisDTO.builder()
                .totalFeedbacks(totalFeedbacks)
                .positivosPercent(positivosPercent)
                .negativosPercent(negativosPercent)
                .novosClientesHoje((int) novosClientesHoje)
                .build();

        CuponsDTO cuponsDTO = CuponsDTO.builder()
                .cuponsSolicitados(cuponsSolicitados)
                .cuponsValidados(cuponsValidados)
                .build();

        SentimentosDTO sentimentosDTO = SentimentosDTO.builder()
                .positivosPercent(positivosPercent)
                .negativosPercent(negativosPercent)
                .build();

        PrincipaisReclamacoesDTO principaisReclamacoesDTO = PrincipaisReclamacoesDTO.builder()
                .itens(reclamacoes)
                .build();

        TimelineDTO timelineDTO = TimelineDTO.builder()
                .feedbacks(timelineFeedbacks)
                .cupons(timelineCupons)
                .build();

        return DashboardResponseDTO.builder()
                .metricasGerais(metricasGeraisDTO)
                .cupons(cuponsDTO)
                .sentimentos(sentimentosDTO)
                .principaisReclamacoes(principaisReclamacoesDTO)
                .timeline(timelineDTO)
                .build();
    }

    // ----------- MÉTODOS AUXILIARES -----------

    private List<ReclamacaoItemDTO> calcularPrincipaisReclamacoes(List<Feedback> feedbacks) {
        // Pega apenas feedbacks negativos com mensagem preenchida
        List<String> mensagens = feedbacks.stream()
                .filter(f -> f.getNota() <= 3)
                .map(Feedback::getMensagemNegativa)
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(s -> !s.isBlank())
                .collect(Collectors.toList());

        if (mensagens.isEmpty()) {
            return Collections.emptyList();
        }

        // Conta quantas vezes cada mensagem aparece
        Map<String, Long> contagem = mensagens.stream()
                .collect(Collectors.groupingBy(m -> m, Collectors.counting()));

        // Converte para lista de DTOs, ordena por quantidade desc, pega top 5
        return contagem.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .limit(5)
                .map(e -> ReclamacaoItemDTO.builder()
                        .categoria(e.getKey())
                        .quantidade(e.getValue())
                        .build())
                .collect(Collectors.toList());
    }

    private List<TimelinePontoDTO> montarTimelineFeedbacks(LocalDate hoje, List<Feedback> feedbacks) {
        List<TimelinePontoDTO> pontos = new ArrayList<>();

        // últimos 7 dias (do mais antigo pro mais recente)
        for (int i = 6; i >= 0; i--) {
            LocalDate dia = hoje.minusDays(i);

            long qtd = feedbacks.stream()
                    .filter(f -> f.getDataCriacao() != null &&
                            f.getDataCriacao().toLocalDate().isEqual(dia))
                    .count();

            pontos.add(TimelinePontoDTO.builder()
                    .dia(dia.toString())
                    .quantidade(qtd)
                    .build());
        }

        return pontos;
    }

    private List<TimelinePontoDTO> montarTimelineCupons(LocalDate hoje, List<Feedback> feedbacks) {
        List<TimelinePontoDTO> pontos = new ArrayList<>();

        for (int i = 6; i >= 0; i--) {
            LocalDate dia = hoje.minusDays(i);

            long qtd = feedbacks.stream()
                    .filter(f -> f.getDataCriacao() != null &&
                            f.getDataCriacao().toLocalDate().isEqual(dia))
                    .filter(f -> f.getCupom() != null && !f.getCupom().isBlank())
                    .count();

            pontos.add(TimelinePontoDTO.builder()
                    .dia(dia.toString())
                    .quantidade(qtd)
                    .build());
        }

        return pontos;
    }
}
