package com.meuapp.feedback.service;

import com.meuapp.feedback.domain.AdminUser;
import com.meuapp.feedback.domain.Feedback;
import com.meuapp.feedback.domain.Restaurant;
import com.meuapp.feedback.dto.cupom.CupomDetalheDTO;
import com.meuapp.feedback.dto.cupom.CupomListItemDTO;
import com.meuapp.feedback.repository.AdminUserRepository;
import com.meuapp.feedback.repository.FeedbackRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CupomService {

    private final AdminUserRepository adminUserRepository;
    private final FeedbackRepository feedbackRepository;

    private final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private Restaurant getRestaurantFromToken(Long adminId) {
        AdminUser admin = adminUserRepository.findById(adminId)
                .orElseThrow(() -> new RuntimeException("Admin não encontrado"));

        return admin.getRestaurant();
    }

    // LISTAR CUPONS
    public Page<CupomListItemDTO> listarCupons(Long adminId, Pageable pageable,
                                               Boolean somenteValidados) {

        Restaurant restaurant = getRestaurantFromToken(adminId);

        Page<Feedback> page;

        if (somenteValidados == null) {
            page = feedbackRepository.findByRestaurant(restaurant, pageable);
        } else if (somenteValidados) {
            page = feedbackRepository.findByRestaurantAndCupomValidadoTrue(restaurant, pageable);
        } else {
            page = feedbackRepository.findByRestaurantAndCupomValidadoFalse(restaurant, pageable);
        }

        return page.map(f -> CupomListItemDTO.builder()
                .id(f.getId())
                .nome(f.getNome())
                .email(f.getEmail())
                .whatsapp(f.getWhatsapp())
                .dataCriacao(f.getDataCriacao().format(dtf))
                .cupom(f.getCupom())
                .cupomValidado(Boolean.TRUE.equals(f.getCupomValidado()))
                .tipoFeedback(f.getNota() >= 4 ? "POSITIVO" : "NEGATIVO")
                .build());
    }

    // VALIDAÇÃO DE CUPOM
    public void validarCupom(Long adminId, Long feedbackId) {

        Restaurant restaurant = getRestaurantFromToken(adminId);

        Feedback f = feedbackRepository.findById(feedbackId)
                .orElseThrow(() -> new RuntimeException("Feedback não encontrado"));

        if (!f.getRestaurant().getId().equals(restaurant.getId())) {
            throw new RuntimeException("Este cupom pertence a outro restaurante!");
        }

        f.setCupomValidado(true);
        f.setDataValidacaoCupom(java.time.LocalDateTime.now());

        feedbackRepository.save(f);
    }

    // DETALHES
    public CupomDetalheDTO detalhes(Long adminId, Long id) {

        Restaurant restaurant = getRestaurantFromToken(adminId);

        Feedback f = feedbackRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Feedback não encontrado"));

        if (!f.getRestaurant().getId().equals(restaurant.getId())) {
            throw new RuntimeException("Não autorizado.");
        }

        return CupomDetalheDTO.builder()
                .id(f.getId())
                .nome(f.getNome())
                .email(f.getEmail())
                .whatsapp(f.getWhatsapp())
                .itemConsumido(f.getItemConsumido())
                .nota(f.getNota())
                .mensagemNegativa(f.getMensagemNegativa())
                .dataCriacao(f.getDataCriacao().format(dtf))
                .cupom(f.getCupom())
                .cupomValidado(Boolean.TRUE.equals(f.getCupomValidado()))
                .dataValidacao(f.getDataValidacaoCupom() != null ? f.getDataValidacaoCupom().format(dtf) : null)
                .build();
    }
}
