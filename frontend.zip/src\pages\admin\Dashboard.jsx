import { useEffect, useState, useMemo } from "react";
import { Bar, Doughnut } from "react-chartjs-2";

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Tooltip,
  Legend,
} from "chart.js";

import { useAuth } from "../../context/AuthContext";
import {
  getDashboard,
  getFeedbacks,
  getHorariosCriticos,
} from "../../api/dashboard";

ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Tooltip, Legend);

const API_BASE = "http://localhost:8080/admin";

export default function Dashboard() {
  const { token, logout } = useAuth();

  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState(null);

  const [dadosDashboard, setDadosDashboard] = useState(null);
  const [horariosCriticos, setHorariosCriticos] = useState([]);
  const [feedbacks, setFeedbacks] = useState([]);

  // filtros da tabela
  const [busca, setBusca] = useState("");
  const [filtroTipo, setFiltroTipo] = useState(""); // POSITIVO | NEGATIVO
  const [filtroValidado, setFiltroValidado] = useState(""); // true | false

  // estado do popup de detalhe
  const [detalheAberto, setDetalheAberto] = useState(false);
  const [detalheLoading, setDetalheLoading] = useState(false);
  const [detalheErro, setDetalheErro] = useState(null);
  const [detalhe, setDetalhe] = useState(null);

  // ─────────────────────────────
  // Carregar dashboard + horários + feedbacks
  // ─────────────────────────────
  useEffect(() => {
    if (!token) return;

    async function carregarTudo() {
      try {
        setLoading(true);
        setErro(null);

        const [dash, horarios, tabela] = await Promise.all([
          getDashboard(token),
          getHorariosCriticos(token),
          getFeedbacks(token, { page: 0, size: 20 }),
        ]);

        setDadosDashboard(dash);
        setHorariosCriticos(horarios || []);
        setFeedbacks(tabela?.content || tabela || []);
      } catch (e) {
        console.error(e);
        setErro("Erro ao carregar informações do dashboard.");
      } finally {
        setLoading(false);
      }
    }

    carregarTudo();
  }, [token]);

  // ─────────────────────────────
  // Abrir popup de detalhe
  // ─────────────────────────────
  async function abrirDetalhe(feedbackId) {
    if (!feedbackId || !token) return;

    try {
      setDetalheErro(null);
      setDetalheLoading(true);

      const res = await fetch(`${API_BASE}/feedbacks/${feedbackId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!res.ok) {
        throw new Error(`Erro ao buscar feedback (${res.status})`);
      }

      const data = await res.json();
      setDetalhe(data);
      setDetalheAberto(true);
    } catch (e) {
      console.error(e);
      setDetalhe(null);
      setDetalheErro("Não foi possível carregar o detalhe do feedback.");
      setDetalheAberto(true);
    } finally {
      setDetalheLoading(false);
    }
  }

  function fecharDetalhe() {
    setDetalheAberto(false);
    setDetalhe(null);
    setDetalheErro(null);
  }

  // ─────────────────────────────
  // Filtros da tabela
  // ─────────────────────────────
  async function aplicarFiltros(e) {
    e.preventDefault();
    if (!token) return;

    try {
      setLoading(true);
      setErro(null);

      const params = {
        page: 0,
        size: 20,
      };

      if (busca) {
        // Vamos mandar a mesma busca para nome/email/cupom
        params.nome = busca;
        params.email = busca;
        params.cupom = busca;
      }

      if (filtroTipo) params.tipo = filtroTipo;
      if (filtroValidado) params.validado = filtroValidado;

      const tabela = await getFeedbacks(token, params);
      setFeedbacks(tabela?.content || tabela || []);
    } catch (e) {
      console.error(e);
      setErro("Erro ao filtrar feedbacks.");
    } finally {
      setLoading(false);
    }
  }

  // ─────────────────────────────
  // Dados derivados do dashboard
  // ─────────────────────────────
  const metricas = dadosDashboard?.metricasGerais || {};
  const cupons = dadosDashboard?.cupons || {};
  const sentimentos = dadosDashboard?.sentimentos || {};
  const timeline = dadosDashboard?.timeline || [];

  // labels + séries para o gráfico de barras
  const graficoBarraData = useMemo(() => {
    if (!timeline.length) {
      return {
        labels: ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"],
        datasets: [
          {
            label: "Feedbacks",
            data: [5, 9, 7, 11, 13, 15, 12, 14, 16, 18, 19, 20],
            backgroundColor: "rgba(59,130,246,0.7)",
            borderRadius: 6,
          },
          {
            label: "Cupons",
            data: [3, 5, 4, 6, 8, 9, 7, 8, 10, 12, 13, 14],
            backgroundColor: "rgba(244,114,182,0.7)",
            borderRadius: 6,
          },
        ],
      };
    }

    const labels = timeline.map(
      (p) => p.label || p.mes || p.data || ""
    );
    const feedbackSeries = timeline.map(
      (p) => p.feedbacks || p.totalFeedbacks || p.total || 0
    );
    const cuponsSeries = timeline.map(
      (p) => p.cupons || p.totalCupons || 0
    );

    return {
      labels,
      datasets: [
        {
          label: "Feedbacks",
          data: feedbackSeries,
          backgroundColor: "rgba(59,130,246,0.7)",
          borderRadius: 6,
        },
        {
          label: "Cupons",
          data: cuponsSeries,
          backgroundColor: "rgba(244,114,182,0.7)",
          borderRadius: 6,
        },
      ],
    };
  }, [timeline]);

  // dados gráfico donut de sentimentos
  const graficoDonutData = useMemo(() => {
    const positivos =
      sentimentos.positivosPercent ??
      sentimentos.percentualPositivos ??
      metricas.positivosPercent ??
      0;

    const negativos =
      sentimentos.negativosPercent ??
      sentimentos.percentualNegativos ??
      metricas.negativosPercent ??
      0;

    const restante = Math.max(0, 100 - (positivos + negativos));

    return {
      labels: ["Positivos", "Negativos", "Neutros"],
      datasets: [
        {
          data: [positivos, negativos, restante],
          backgroundColor: [
            "rgba(34,197,94,0.8)",
            "rgba(239,68,68,0.8)",
            "rgba(148,163,184,0.8)",
          ],
          borderWidth: 0,
        },
      ],
    };
  }, [sentimentos, metricas]);

  if (loading && !dadosDashboard) {
    return (
      <div className="min-h-screen bg-[#050816] text-white flex items-center justify-center">
        Carregando Dashboard...
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-[#050816] via-[#020617] to-black text-white px-10 py-8">
      {/* HEADER */}
      <header className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold">
            <span className="text-white">Review </span>
            <span className="text-indigo-400">Prime AI</span>
          </h1>
          <p className="text-xs text-gray-400 mt-1">
            Painel de Gestão de Feedbacks de Clientes
          </p>
        </div>

        <div className="flex items-center gap-4">
          <button className="px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-sm hover:bg-white/10">
            ⚙ Configurações
          </button>
          <button
            onClick={logout}
            className="px-4 py-2 rounded-lg bg-red-500/90 text-sm font-medium hover:bg-red-500"
          >
            Logout
          </button>
        </div>
      </header>

      {erro && (
        <div className="mb-6 text-sm text-red-400 bg-red-500/10 border border-red-500/30 px-4 py-3 rounded-lg">
          {erro}
        </div>
      )}

      {/* 1ª LINHA - CARDS PRINCIPAIS */}
      <section className="grid grid-cols-6 gap-4 mb-8">
        <KpiCard
          titulo="Total de Feedbacks"
          valor={metricas.totalFeedbacks ?? 0}
        />
        <KpiCard
          titulo="Feedbacks Positivos"
          valor={`${(metricas.positivosPercent ?? 0).toFixed?.(1) ?? metricas.positivosPercent ?? 0}%`}
          destaque="up"
        />
        <KpiCard
          titulo="Feedbacks Negativos"
          valor={`${(metricas.negativosPercent ?? 0).toFixed?.(1) ?? metricas.negativosPercent ?? 0}%`}
          destaque="down"
        />
        <KpiCard
          titulo="Cupons Solicitados"
          valor={cupons.cuponsSolicitados ?? 0}
        />
        <KpiCard
          titulo="Cupons Validados"
          valor={cupons.cuponsValidados ?? 0}
        />
        <KpiCard
          titulo="Novos Clientes Hoje"
          valor={metricas.novosClientesHoje ?? 0}
        />
      </section>

      {/* 2ª LINHA - GRÁFICO + CTA IA + DONUT */}
      <section className="grid grid-cols-3 gap-6 mb-10">
        {/* Gráfico barras */}
        <div className="col-span-2 bg-[#0b1120] border border-white/10 rounded-2xl px-6 py-5 shadow-xl">
          <h3 className="text-sm font-semibold mb-3">
            Feedbacks e Cupons ao Longo do Tempo
          </h3>
          <div className="h-64">
            <Bar
              data={graficoBarraData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    labels: { color: "#e5e7eb", boxWidth: 12 },
                  },
                },
                scales: {
                  x: { ticks: { color: "#9ca3af" }, grid: { display: false } },
                  y: {
                    ticks: { color: "#9ca3af" },
                    grid: { color: "rgba(75,85,99,0.3)" },
                  },
                },
              }}
            />
          </div>
        </div>

        {/* CTA IA + Donut */}
        <div className="col-span-1 flex flex-col gap-4">
          <button className="bg-gradient-to-r from-purple-600 to-pink-500 rounded-2xl px-5 py-4 text-left shadow-lg shadow-purple-500/40">
            <p className="text-xs text-white/80">Campanhas inteligentes</p>
            <p className="text-sm font-semibold">
              ✨ Gerar E-mails Promocionais com IA
            </p>
            <p className="text-[11px] text-white/70 mt-1">
              Crie campanhas personalizadas automaticamente.
            </p>
          </button>

          <div className="bg-[#0b1120] border border-white/10 rounded-2xl px-5 py-4 shadow-xl flex flex-col items-center">
            <h3 className="text-sm font-semibold mb-3 self-start">
              Distribuição de Sentimentos
            </h3>
            <div className="w-40 h-40 mb-2">
              <Doughnut
                data={graficoDonutData}
                options={{
                  plugins: {
                    legend: {
                      labels: { color: "#e5e7eb", boxWidth: 10 },
                      position: "bottom",
                    },
                  },
                }}
              />
            </div>
          </div>
        </div>
      </section>

      {/* 3ª LINHA - ASSISTENTE IA COMPLETO */}
      <section className="bg-[#0b1120] border border-white/10 rounded-2xl px-6 py-6 mb-8 shadow-xl">
        <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <span className="text-sky-400 text-xl">💡</span>
          Assistente Inteligente de Análise (IA)
        </h2>

        {/* 8 cards */}
        <div className="grid grid-cols-4 gap-4 mb-6 text-sm">
          <IAcard
            cor="from-red-600/80 to-red-800/80"
            titulo="Resumo dos Feedbacks Negativos de Hoje"
            texto="Principais reclamações: atraso na entrega, produto etc."
          />
          <IAcard
            cor="from-emerald-600/80 to-emerald-800/80"
            titulo="Alerta de Tendência"
            texto="Aumento recente nas menções positivas nas últimas 48h."
          />
          <IAcard
            cor="from-sky-600/80 to-sky-800/80"
            titulo="Sugestões de Melhoria"
            texto="Pontos de atrito detectados em vários feedbacks."
          />
          <IAcard
            cor="from-purple-600/80 to-purple-800/80"
            titulo="Recomendações de Campanha"
            texto="Enviar promoção para clientes inativos."
          />
          <IAcard
            cor="from-cyan-600/80 to-cyan-800/80"
            titulo="Padrões Detectados"
            texto="Produtos que geram maior satisfação."
          />
          <IAcard
            cor="from-teal-600/80 to-teal-800/80"
            titulo="Previsão de Horário dos Clientes"
            texto="Identificação dos horários de maior movimento."
          />
          <IAcard
            cor="from-indigo-600/80 to-indigo-800/80"
            titulo="Análise Automática de Feedbacks"
            texto="A IA analisa textos e detecta padrões."
          />
          <IAcard
            cor="from-amber-600/80 to-amber-800/80"
            titulo="Ações Sugeridas pela IA"
            texto="Sugestões operacionais e estratégias."
          />
        </div>

        {/* Horário x Previsão */}
        <div className="grid grid-cols-2 gap-6">
          {/* Horário com mais reclamações */}
          <div className="bg-[#020617] border border-red-500/30 rounded-2xl px-5 py-4">
            <h3 className="text-sm font-semibold mb-2 flex items-center gap-2">
              <span className="text-red-400 text-lg">⏱</span>
              Horário com mais Reclamações
            </h3>

            {horariosCriticos?.length ? (
              <>
                <p className="text-3xl font-bold mt-3">
                  {horariosCriticos[0].horaInicio} - {horariosCriticos[0].horaFim}
                </p>
                <p className="text-xs text-gray-400 mt-1">
                  {horariosCriticos[0].totalReclamacoes} reclamações no período
                </p>

                <div className="mt-5">
                  <div className="w-full h-2 rounded-full bg-white/10">
                    <div className="h-2 rounded-full bg-red-500" style={{ width: "32%" }} />
                  </div>
                  <p className="text-[11px] text-red-400 mt-1 text-right">32%</p>
                </div>
              </>
            ) : (
              <p className="text-xs text-gray-400 mt-3">Sem dados de reclamações por horário.</p>
            )}
          </div>

          {/* Previsão de satisfação */}
          <div className="bg-[#020617] border border-emerald-500/30 rounded-2xl px-5 py-4">
            <h3 className="text-sm font-semibold mb-2 flex items-center gap-2">
              <span className="text-emerald-400 text-lg">📈</span>
              Previsão de Satisfação
            </h3>

            <p className="text-3xl font-bold mt-3">78%</p>
            <p className="text-xs text-emerald-400 mt-1">↗ 82% (projeção)</p>

            <div className="mt-5">
              <div className="w-full h-2 rounded-full bg-white/10">
                <div className="h-2 rounded-full bg-emerald-500" style={{ width: "89%" }} />
              </div>
              <p className="text-[11px] text-emerald-400 mt-1 text-right">89%</p>
            </div>
          </div>
        </div>
      </section>

      {/* 4ª LINHA - TABELA DE FEEDBACKS */}
      <section className="bg-[#0b1120] border border-white/10 rounded-2xl px-6 py-6 mb-16 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <span className="text-sky-400 text-lg">💬</span>
            Feedbacks Completos
          </h2>

          <button className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-sm font-medium">
            🤖 Responder Feedback com IA
          </button>
        </div>

        {/* filtros */}
        <form
          onSubmit={aplicarFiltros}
          className="flex flex-wrap gap-3 mb-4 text-xs items-end"
        >
          <div className="flex flex-col">
            <label className="text-gray-400 mb-1">Buscar (nome / email / cupom)</label>
            <input
              type="text"
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              className="bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-sky-500"
              placeholder="Digite um termo..."
            />
          </div>

          <div className="flex flex-col">
            <label className="text-gray-400 mb-1">Tipo</label>
            <select
              value={filtroTipo}
              onChange={(e) => setFiltroTipo(e.target.value)}
              className="bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-xs"
            >
              <option value="">Todos</option>
              <option value="POSITIVO">Positivos</option>
              <option value="NEGATIVO">Negativos</option>
            </select>
          </div>

          <div className="flex flex-col">
            <label className="text-gray-400 mb-1">Cupom validado?</label>
            <select
              value={filtroValidado}
              onChange={(e) => setFiltroValidado(e.target.value)}
              className="bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-xs"
            >
              <option value="">Todos</option>
              <option value="true">Validados</option>
              <option value="false">Não validados</option>
            </select>
          </div>

          <button
            type="submit"
            className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-xs font-medium"
          >
            Aplicar filtros
          </button>
        </form>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="text-gray-400 border-b border-white/10">
              <tr>
                <th className="py-2 pr-3">Cliente</th>
                <th className="py-2 pr-3">Email</th>
                <th className="py-2 pr-3">WhatsApp</th>
                <th className="py-2 pr-3">Data</th>
                <th className="py-2 pr-3 w-[30%]">Feedback</th>
                <th className="py-2 pr-3">Cupom</th>
                <th className="py-2 pr-3">Status</th>
                <th className="py-2 pr-3 text-center">Ação</th>
              </tr>
            </thead>
            <tbody>
              {feedbacks.map((f) => (
                <tr
                  key={f.id || `${f.email}-${f.dataFeedback}`}
                  className="border-b border-white/5 hover:bg-white/5"
                >
                  <td className="py-2 pr-3">{f.nome || f.nomeCliente || "-"}</td>
                  <td className="py-2 pr-3">
                    {f.email || f.emailCliente || "-"}
                  </td>
                  <td className="py-2 pr-3">
                    {f.whatsapp || f.telefone || "-"}
                  </td>
                  <td className="py-2 pr-3">
                    {f.dataFeedback || f.data || "-"}
                  </td>
                  <td className="py-2 pr-3 text-gray-200">
                    {f.mensagem || f.feedback || f.mensagemNegativa || "-"}
                  </td>
                  <td className="py-2 pr-3">
                    {f.cupomCodigo || f.cupom || "-"}
                  </td>
                  <td className="py-2 pr-3">
                    {f.statusCupom ||
                      (f.cupomValidado ? "Validado" : "Não valiado")}
                  </td>
                  <td className="py-2 pr-3 text-center">
                    {f.id ? (
                      <button
                        type="button"
                        onClick={() => abrirDetalhe(f.id)}
                        className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-cyan-500/10 text-cyan-400 hover:bg-cyan-500/20 border border-cyan-500/40"
                        title="Ver detalhes"
                      >
                        👁
                      </button>
                    ) : (
                      "-"
                    )}
                  </td>
                </tr>
              ))}

              {!feedbacks.length && (
                <tr>
                  <td
                    colSpan={8}
                    className="py-6 text-center text-gray-500 text-xs"
                  >
                    Nenhum feedback encontrado para os filtros atuais.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* MODAL DETALHE */}
      {detalheAberto && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
          <div className="bg-[#020617] border border-white/20 rounded-2xl w-full max-w-lg px-6 py-5 shadow-2xl relative">
            <button
              onClick={fecharDetalhe}
              className="absolute right-4 top-4 text-gray-400 hover:text-white text-lg"
            >
              ✕
            </button>

            <h3 className="text-lg font-semibold mb-4">
              Detalhes do Feedback
            </h3>

            {detalheLoading && (
              <p className="text-sm text-gray-300">Carregando detalhes...</p>
            )}

            {detalheErro && (
              <p className="text-sm text-red-400 mb-2">{detalheErro}</p>
            )}

            {!detalheLoading && detalhe && (
              <div className="space-y-3 text-sm">
                <div>
                  <p className="text-gray-400">Cliente</p>
                  <p className="font-medium">
                    {detalhe.nome || detalhe.nomeCliente || "-"}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-gray-400">Email</p>
                    <p className="font-medium break-all">
                      {detalhe.email || detalhe.emailCliente || "-"}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-400">WhatsApp</p>
                    <p className="font-medium">
                      {detalhe.whatsapp || detalhe.telefone || "-"}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-gray-400">Data</p>
                    <p className="font-medium">
                      {detalhe.dataFeedback || detalhe.data || "-"}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-400">Nota / Tipo</p>
                    <p className="font-medium">
                      {detalhe.nota ?? detalhe.tipo ?? "-"}
                    </p>
                  </div>
                </div>

                <div>
                  <p className="text-gray-400">Feedback</p>
                  <p className="font-medium text-gray-100">
                    {detalhe.mensagem ||
                      detalhe.feedback ||
                      detalhe.mensagemNegativa ||
                      "-"}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-gray-400">Cupom</p>
                    <p className="font-medium">
                      {detalhe.cupomCodigo || detalhe.cupom || "-"}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-400">Status do Cupom</p>
                    <p className="font-medium">
                      {detalhe.statusCupom ||
                        (detalhe.cupomValidado ? "Validado" : "Não validado")}
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="mt-5 flex justify-end gap-3">
              <button
                onClick={fecharDetalhe}
                className="px-4 py-2 rounded-lg bg-white/5 border border-white/15 text-xs hover:bg-white/10"
              >
                Fechar
              </button>
              {/* aqui depois dá pra colocar botão "Responder com IA" usando os dados do detalhe */}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* Componentes auxiliares */

function KpiCard({ titulo, valor, destaque }) {
  const cor =
    destaque === "up"
      ? "text-emerald-400"
      : destaque === "down"
      ? "text-red-400"
      : "text-white";

  return (
    <div className="bg-[#0b1120] border border-white/10 rounded-2xl px-5 py-4 shadow-lg flex flex-col justify-between">
      <p className="text-xs text-gray-400 mb-1">{titulo}</p>
      <p className={`text-2xl font-bold ${cor}`}>{valor}</p>
    </div>
  );
}

function IAcard({ cor, titulo, texto }) {
  return (
    <div
      className={`rounded-xl bg-gradient-to-r ${cor} px-4 py-3 border border-white/10 shadow-md`}
    >
      <p className="text-xs font-semibold mb-1">{titulo}</p>
      <p className="text-[11px] text-gray-100/90">{texto}</p>
    </div>
  );
}
