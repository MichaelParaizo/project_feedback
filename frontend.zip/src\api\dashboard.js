// src/api/dashboard.js

const API_BASE_URL = "http://localhost:8080";

// Helper pra montar headers com token
function authHeaders(token) {
  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`,
  };
}

// Helper genérico de fetch
async function request(path, options = {}) {
  const res = await fetch(`${API_BASE_URL}${path}`, options);

  if (!res.ok) {
    let msg = "Erro na requisição";
    try {
      const data = await res.json();
      if (data?.message) msg = data.message;
    } catch {
      // ignore
    }
    throw new Error(msg);
  }

  if (res.status === 204) return null; // sem conteúdo
  return res.json();
}

/**
 * GET /admin/dashboard
 * Métricas gerais para o topo do painel.
 */
export async function getDashboard(token) {
  return request("/admin/dashboard", {
    method: "GET",
    headers: authHeaders(token),
  });
}

/**
 * GET /admin/feedbacks
 * Lista paginada de feedbacks com filtros.
 *
 * params:
 *  - page, size
 *  - tipo (POSITIVO | NEGATIVO)
 *  - validado (true | false)
 *  - nome, email, cupom
 *  - dataInicio, dataFim (yyyy-MM-dd)
 */
export async function getFeedbacks(token, params = {}) {
  const searchParams = new URLSearchParams();

  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") {
      searchParams.append(key, value);
    }
  });

  const query = searchParams.toString();
  const url = query ? `/admin/feedbacks?${query}` : "/admin/feedbacks";

  return request(url, {
    method: "GET",
    headers: authHeaders(token),
  });
}

/**
 * GET /admin/feedbacks/{id}
 * Detalhe completo de um feedback.
 */
export async function getFeedbackById(token, id) {
  return request(`/admin/feedbacks/${id}`, {
    method: "GET",
    headers: authHeaders(token),
  });
}

/**
 * POST /admin/feedbacks/{id}/responder-email
 * Envia uma resposta por e-mail para feedback negativo.
 * body: { mensagem: "texto da resposta" }
 */
export async function responderFeedbackEmail(token, id, mensagem) {
  return request(`/admin/feedbacks/${id}/responder-email`, {
    method: "POST",
    headers: authHeaders(token),
    body: JSON.stringify({ mensagem }),
  });
}

/**
 * PATCH /admin/feedbacks/{id}/validar-cupom
 * Marca cupom do feedback como validado.
 */
export async function validarCupomDoFeedback(token, id) {
  return request(`/admin/feedbacks/${id}/validar-cupom`, {
    method: "PATCH",
    headers: authHeaders(token),
  });
}

/**
 * GET /admin/feedbacks/horarios
 * Retorna horários com mais reclamações (nota < 4).
 */
export async function getHorariosCriticos(token) {
  return request("/admin/feedbacks/horarios", {
    method: "GET",
    headers: authHeaders(token),
  });
}

/**
 * GET /admin/cupoms
 * Lista de cupons com status.
 */
export async function getCupons(token, params = {}) {
  const searchParams = new URLSearchParams();

  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") {
      searchParams.append(key, value);
    }
  });

  const query = searchParams.toString();
  const url = query ? `/admin/cupoms?${query}` : "/admin/cupoms";

  return request(url, {
    method: "GET",
    headers: authHeaders(token),
  });
}

/**
 * PATCH /admin/cupoms/{id}/validar
 * Valida um cupom diretamente.
 */
export async function validarCupom(token, id) {
  return request(`/admin/cupoms/${id}/validar`, {
    method: "PATCH",
    headers: authHeaders(token),
  });
}
