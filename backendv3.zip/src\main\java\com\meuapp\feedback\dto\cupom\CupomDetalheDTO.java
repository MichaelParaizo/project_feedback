package com.meuapp.feedback.dto.cupom;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CupomDetalheDTO {

    private Long id;
    private String nome;
    private String email;
    private String whatsapp;

    private String itemConsumido;
    private int nota;
    private String mensagemNegativa;

    private String dataCriacao;

    private String cupom;
    private boolean cupomValidado;
    private String dataValidacao;
}
