package com.meuapp.feedback.service;

import com.meuapp.feedback.domain.AdminUser;
import com.meuapp.feedback.domain.Feedback;
import com.meuapp.feedback.domain.Restaurant;
import com.meuapp.feedback.dto.admin.FeedbackDetailsAdminDTO;
import com.meuapp.feedback.dto.admin.FeedbackListItemDTO;
import com.meuapp.feedback.repository.FeedbackRepository;
import com.meuapp.feedback.repository.RestaurantRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AdminFeedbackService {

    private final FeedbackRepository feedbackRepository;
    private final RestaurantRepository restaurantRepository;

    public Page<FeedbackListItemDTO> listarFeedbacks(
            AdminUser admin,
            Integer page,
            Integer size,
            String tipo,          // "POSITIVO" | "NEGATIVO" | null
            Boolean validado,     // true | false | null
            String nome,
            String email,
            String cupom,
            LocalDate dataInicio,
            LocalDate dataFim
    ) {

        Restaurant restaurant = restaurantRepository.findById(admin.getRestaurant().getId())
                .orElseThrow(() -> new RuntimeException("Restaurante não encontrado"));

        List<Feedback> feedbacks = feedbackRepository.findByRestaurant(restaurant);

        // FILTROS

        if (tipo != null && !tipo.isBlank()) {
            String tipoUpper = tipo.toUpperCase(Locale.ROOT);
            feedbacks = feedbacks.stream()
                    .filter(f -> {
                        boolean positivo = f.getNota() >= 4;
                        boolean negativo = f.getNota() <= 3;
                        if ("POSITIVO".equals(tipoUpper)) {
                            return positivo;
                        } else if ("NEGATIVO".equals(tipoUpper)) {
                            return negativo;
                        }
                        return true;
                    })
                    .collect(Collectors.toList());
        }

        if (validado != null) {
            feedbacks = feedbacks.stream()
                    .filter(f -> Boolean.TRUE.equals(f.getCupomValidado()) == validado)
                    .collect(Collectors.toList());
        }

        if (nome != null && !nome.isBlank()) {
            String nomeLower = nome.toLowerCase(Locale.ROOT);
            feedbacks = feedbacks.stream()
                    .filter(f -> f.getNome() != null &&
                            f.getNome().toLowerCase(Locale.ROOT).contains(nomeLower))
                    .collect(Collectors.toList());
        }

        if (email != null && !email.isBlank()) {
            String emailLower = email.toLowerCase(Locale.ROOT);
            feedbacks = feedbacks.stream()
                    .filter(f -> f.getEmail() != null &&
                            f.getEmail().toLowerCase(Locale.ROOT).contains(emailLower))
                    .collect(Collectors.toList());
        }

        if (cupom != null && !cupom.isBlank()) {
            String cupomUpper = cupom.toUpperCase(Locale.ROOT);
            feedbacks = feedbacks.stream()
                    .filter(f -> f.getCupom() != null &&
                            f.getCupom().toUpperCase(Locale.ROOT).contains(cupomUpper))
                    .collect(Collectors.toList());
        }

        if (dataInicio != null) {
            feedbacks = feedbacks.stream()
                    .filter(f -> f.getDataCriacao() != null &&
                            !f.getDataCriacao().toLocalDate().isBefore(dataInicio))
                    .collect(Collectors.toList());
        }

        if (dataFim != null) {
            feedbacks = feedbacks.stream()
                    .filter(f -> f.getDataCriacao() != null &&
                            !f.getDataCriacao().toLocalDate().isAfter(dataFim))
                    .collect(Collectors.toList());
        }

        // Ordena por data desc (mais recente primeiro)
        feedbacks.sort(Comparator
                .comparing(Feedback::getDataCriacao,
                        Comparator.nullsLast(Comparator.naturalOrder()))
                .reversed()
                .thenComparing(Feedback::getId, Comparator.nullsLast(Comparator.reverseOrder()))
        );

        // Paginação manual
        int pageNumber = (page != null && page >= 0) ? page : 0;
        int pageSize = (size != null && size > 0) ? size : 20;

        int fromIndex = pageNumber * pageSize;
        int toIndex = Math.min(fromIndex + pageSize, feedbacks.size());

        List<FeedbackListItemDTO> content;

        if (fromIndex >= feedbacks.size()) {
            content = List.of();
        } else {
            content = feedbacks.subList(fromIndex, toIndex).stream()
                    .map(this::mapToListDTO)
                    .collect(Collectors.toList());
        }

        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        return new PageImpl<>(content, pageable, feedbacks.size());
    }

    public FeedbackDetailsAdminDTO buscarDetalhe(AdminUser admin, Long id) {
        Feedback feedback = feedbackRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Feedback não encontrado"));

        if (feedback.getRestaurant() == null ||
                !Objects.equals(feedback.getRestaurant().getId(), admin.getRestaurant().getId())) {
            // Garante que o admin só veja feedback do próprio restaurante
            throw new RuntimeException("Feedback não pertence ao restaurante do admin");
        }

        return mapToDetailsDTO(feedback);
    }

    // --------- Mapeamentos auxiliares ---------

    private FeedbackListItemDTO mapToListDTO(Feedback f) {
        String tipoFeedback = (f.getNota() >= 4) ? "POSITIVO" : "NEGATIVO";

        String mensagem = (f.getNota() <= 3) ? f.getMensagemNegativa() : null;

        return FeedbackListItemDTO.builder()
                .id(f.getId())
                .nome(f.getNome())
                .email(f.getEmail())
                .whatsapp(f.getWhatsapp())
                .data(f.getDataCriacao())
                .tipoFeedback(tipoFeedback)
                .mensagem(mensagem)
                .itemConsumido(f.getItemConsumido())
                .cupom(f.getCupom())
                .cupomValidado(Boolean.TRUE.equals(f.getCupomValidado()))
                .nota(f.getNota())
                .build();
    }

    private FeedbackDetailsAdminDTO mapToDetailsDTO(Feedback f) {
        String tipoFeedback = (f.getNota() >= 4) ? "POSITIVO" : "NEGATIVO";

        return FeedbackDetailsAdminDTO.builder()
                .id(f.getId())
                .nome(f.getNome())
                .email(f.getEmail())
                .whatsapp(f.getWhatsapp())
                .dataCriacao(f.getDataCriacao())
                .nota(f.getNota())
                .tipoFeedback(tipoFeedback)
                .itemConsumido(f.getItemConsumido())
                .mensagemNegativa(f.getMensagemNegativa())
                .linkGoogle(f.getLinkGoogle())
                .cupom(f.getCupom())
                .cupomValidado(Boolean.TRUE.equals(f.getCupomValidado()))
                .dataValidacaoCupom(f.getDataValidacaoCupom())
                .consentimentoLgpd(Boolean.TRUE.equals(f.getConsentimentoLgpd()))
                .restauranteNome(f.getRestaurant() != null ? f.getRestaurant().getNome() : null)
                .build();
    }
}
