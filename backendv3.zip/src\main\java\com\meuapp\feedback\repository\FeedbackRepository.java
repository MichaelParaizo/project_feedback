package com.meuapp.feedback.repository;

import com.meuapp.feedback.domain.Feedback;
import com.meuapp.feedback.domain.Restaurant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;


import java.util.List;
import java.util.Optional;

public interface FeedbackRepository extends JpaRepository<Feedback, Long> {

    // --- LISTAGEM (usa paginação) ---
    Page<Feedback> findByRestaurant(Restaurant restaurant, Pageable pageable);

    Page<Feedback> findByRestaurantAndCupomValidadoTrue(Restaurant restaurant, Pageable pageable);

    Page<Feedback> findByRestaurantAndCupomValidadoFalse(Restaurant restaurant, Pageable pageable);

    // --- DASHBOARD (usa listas normais) ---
    List<Feedback> findByRestaurant(Restaurant restaurant);

    List<Feedback> findByRestaurantAndNotaLessThanEqual(Restaurant restaurant, int nota);

    List<Feedback> findByRestaurantAndNotaGreaterThanEqual(Restaurant restaurant, int nota);

    // Buscar cupom (continua igual)
    Optional<Feedback> findByCupom(String cupom);
}


