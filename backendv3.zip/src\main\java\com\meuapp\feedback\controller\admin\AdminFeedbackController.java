package com.meuapp.feedback.controller.admin;

import com.meuapp.feedback.domain.AdminUser;
import com.meuapp.feedback.dto.admin.FeedbackDetailsAdminDTO;
import com.meuapp.feedback.dto.admin.FeedbackListItemDTO;
import com.meuapp.feedback.service.AdminFeedbackService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/admin/feedbacks")
@RequiredArgsConstructor
public class AdminFeedbackController {

    private final AdminFeedbackService adminFeedbackService;

    @GetMapping
    public Page<FeedbackListItemDTO> listarFeedbacks(
            @AuthenticationPrincipal AdminUser admin,

            @RequestParam(defaultValue = "0") Integer page,
            @RequestParam(defaultValue = "20") Integer size,

            @RequestParam(required = false) String tipo,          // POSITIVO | NEGATIVO
            @RequestParam(required = false) Boolean validado,
            @RequestParam(required = false) String nome,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) String cupom,

            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
                    LocalDate dataInicio,

            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
                    LocalDate dataFim
    ) {
        return adminFeedbackService.listarFeedbacks(
                admin,
                page,
                size,
                tipo,
                validado,
                nome,
                email,
                cupom,
                dataInicio,
                dataFim
        );
    }

    @GetMapping("/{id}")
    public FeedbackDetailsAdminDTO buscarDetalhe(
            @AuthenticationPrincipal AdminUser admin,
            @PathVariable Long id
    ) {
        return adminFeedbackService.buscarDetalhe(admin, id);
    }
}
